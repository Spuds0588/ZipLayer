EXAMPLE LOAN FILE - ZipLayer.js demo
=====================================

Simulated borrower: John A. Smith (SSN 123-45-6789)

Contents:
  W2-2024.pdf            - Wage and Tax Statement
  PayStub-2024-11-15.pdf - Recent pay stub
  SalesContract-2341.pdf - Residential purchase agreement
  DriverLicense.svg      - Scanned driver license (simulated)

All documents are synthetic examples for demonstration purposes only.
